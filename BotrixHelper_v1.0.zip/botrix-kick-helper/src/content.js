console.log("BotRix Helper: Iniciando motor de extensión...");

// CONSTANTES Y ESTADO GLOBAL
const STORAGE_KEY_USERNAME = "botrix_helper_username";
const STORAGE_KEY_POINTS = "botrix_helper_points";
const STORAGE_KEY_NOTIF = "botrix_helper_notif_enabled";
const STORAGE_KEY_MUTE = "botrix_helper_mute_enabled";
const STORAGE_KEY_SOUND = "botrix_helper_sound_type";
const STORAGE_KEY_TARGET = "botrix_helper_target_channel";
const STORAGE_KEY_BONUS_LAST = "botrix_helper_bonus_last";
const STORAGE_KEY_EXTRA_LAST = "botrix_helper_extra_last";
const STORAGE_KEY_CHECK_LAST = "botrix_helper_check_last";
const STORAGE_KEY_BELL_VISIBLE = "botrix_helper_bell_visible";
const STORAGE_KEY_COMMANDS = "botrix_helper_custom_commands";
const STORAGE_KEY_LIVE_ONLY = "botrix_helper_live_only";
const STORAGE_KEY_POINTS_KEYWORDS = "botrix_helper_points_keywords";


// CONFIGURACIÓN DE COMANDOS (Valores por defecto)
const DEFAULT_COMMANDS = {
    check: { label: "!check", cooldown: 1200 },
    bonus: { label: "!bonus", cooldown: 1200 },
    extra: { label: "!extra", cooldown: 1800 }
};

let BOTRIX_COMMANDS = { ...DEFAULT_COMMANDS };

let currentUsername = "";
let currentPoints = 0;
let isNotificationsEnabled = true;
let isMuted = false;
let currentSoundType = "standard";
let targetChannel = "";
let isLiveOnlyEnabled = false;
let currentPointsKeywords = "tienes, has, ahora tienes, total";
let liveCache = { isLive: false, lastCheck: 0 };
let isInitializing = true;

// CANAL DE COMUNICACIÓN ENTRE PESTAÑAS
const bc = new BroadcastChannel('botrix_multi_tab');

let activeTimers = {};
Object.keys(BOTRIX_COMMANDS).forEach(id => { activeTimers[id] = 0; });

let globalTimerInterval = null;

function setButtonState(id, enabled, remaining = 0) {
    const btn = document.getElementById(`botrix-${id}-btn`);
    if (!btn) return;
    btn.disabled = !enabled;
    btn.style.opacity = enabled ? "1" : "0.5";
    btn.style.cursor = enabled ? "pointer" : "not-allowed";
    btn.style.background = enabled ? "rgba(0,231,1,0.1) !important" : "rgba(255,255,255,0.03) !important";
    btn.style.color = enabled ? "#00e701 !important" : "rgba(255,255,255,0.3) !important";
    btn.style.border = enabled ? "1px solid rgba(0,231,1,0.3) !important" : "1px solid rgba(255,255,255,0.1) !important";

    if (!enabled && remaining > 0) {
        const mins = Math.floor(remaining / 60);
        const secs = remaining % 60;
        btn.textContent = `${BOTRIX_COMMANDS[id].label} (${mins}:${secs.toString().padStart(2, '0')})`;
    } else {
        btn.textContent = BOTRIX_COMMANDS[id].label;
    }
}

function startTimer(id, seconds) {
    const endTime = Date.now() + (seconds * 1000);
    localStorage.setItem(`botrix_helper_${id}_end`, endTime);

    hideNotificationBell(true);

    if (id === "check") bc.postMessage({ type: 'CHECK_RESET' });
}

function hideNotificationBell(propagate = true) {
    const bell = document.getElementById("botrix-notif-bell");
    if (bell) bell.style.display = "none";
    localStorage.setItem(STORAGE_KEY_BELL_VISIBLE, "false");

    if (propagate) {
        bc.postMessage({ type: 'HIDE_BELL' });
    }
}

function updateTimers() {
    const ids = Object.keys(BOTRIX_COMMANDS);

    ids.forEach(id => {
        const end = parseInt(localStorage.getItem(`botrix_helper_${id}_end`) || 0);
        const remaining = Math.max(0, Math.floor((end - Date.now()) / 1000));

        // DETECCIÓN DE FINALIZACIÓN
        if (remaining === 0 && activeTimers[id] > 0) {
            triggerNotification(false, `ALARM_${id.toUpperCase()}_TIMEOUT`);
        }

        activeTimers[id] = remaining;

        if (remaining > 0) {
            setButtonState(id, false, remaining);
        } else {
            setButtonState(id, true);
        }
    });
}

function initGlobalLoop() {
    if (globalTimerInterval) clearInterval(globalTimerInterval);
    updateTimers();
    globalTimerInterval = setInterval(updateTimers, 1000);
}

bc.onmessage = (event) => {
    if (!event.data) return;

    if (event.data.type === 'TRIGGER_NOTIF') {
        triggerNotification(true, event.data.signature);
    }

    if (event.data.type === 'CHECK_RESET' || event.data.type === 'HIDE_BELL') {
        hideNotificationBell(false);
    }
};

// SINCRONIZACIÓN DE AJUSTES EN TIEMPO REAL
window.addEventListener('storage', (e) => {
    if (!e.key || !e.key.startsWith('botrix_helper_')) return;

    if (e.key.endsWith('_end')) {
        updateTimers();
        return;
    }

    console.log("[Sincro] Cambio estructural detectado, actualizando panel...");
    loadAllSettings();
});

function loadAllSettings() {
    currentUsername = localStorage.getItem(STORAGE_KEY_USERNAME) || "";
    targetChannel = localStorage.getItem(STORAGE_KEY_TARGET) || "";
    isNotificationsEnabled = localStorage.getItem(STORAGE_KEY_NOTIF) !== "false";
    isMuted = localStorage.getItem(STORAGE_KEY_MUTE) === "true";
    currentSoundType = localStorage.getItem(STORAGE_KEY_SOUND) || "standard";
    isLiveOnlyEnabled = localStorage.getItem(STORAGE_KEY_LIVE_ONLY) === "true";
    currentPointsKeywords = localStorage.getItem(STORAGE_KEY_POINTS_KEYWORDS) || "tienes, has, ahora tienes, total";

    // CARGAR COMANDOS
    const savedCmds = localStorage.getItem(STORAGE_KEY_COMMANDS);
    if (savedCmds) {
        try {
            BOTRIX_COMMANDS = JSON.parse(savedCmds);
        } catch (e) {
            console.error("Error cargando comandos:", e);
            BOTRIX_COMMANDS = { ...DEFAULT_COMMANDS };
        }
    } else {
        BOTRIX_COMMANDS = { ...DEFAULT_COMMANDS };
    }

    // Asegurar que activeTimers tenga todos los IDs
    Object.keys(BOTRIX_COMMANDS).forEach(id => {
        if (!(id in activeTimers)) activeTimers[id] = 0;
    });

    // ACTUALIZAR UI
    const iu = document.getElementById("botrix-username-input");
    const it = document.getElementById("botrix-target-channel");
    const ce = document.getElementById("check-notif-events");
    const cm = document.getElementById("check-notif-mute");
    const ss = document.getElementById("botrix-sound-type");

    if (iu) iu.value = currentUsername;
    if (it) it.value = targetChannel;
    if (ce) ce.checked = isNotificationsEnabled;
    if (cm) {
        cm.checked = isMuted;
        cm.disabled = !isNotificationsEnabled;
    }
    if (ss) ss.value = currentSoundType;

    const cl = document.getElementById("check-notif-live-only");
    if (cl) cl.checked = isLiveOnlyEnabled;
    const pk = document.getElementById("botrix-points-keywords");
    if (pk) pk.value = currentPointsKeywords;

    console.log(`[Config] Username: ${currentUsername}, Target: ${targetChannel || 'Todos'}`);

    if (localStorage.getItem(STORAGE_KEY_BELL_VISIBLE) === "true") {
        const bell = document.getElementById("botrix-notif-bell");
        if (bell) bell.style.display = "block";
    } else {
        const bell = document.getElementById("botrix-notif-bell");
        if (bell) bell.style.display = "none";
    }

    renderCommandButtons();
    renderCommandEditor();
    updateTimers();
}

function renderCommandButtons() {
    const cmdContainer = document.getElementById("botrix-commands-container");
    if (!cmdContainer) return;

    cmdContainer.innerHTML = "";
    Object.keys(BOTRIX_COMMANDS).forEach(id => {
        const cmd = BOTRIX_COMMANDS[id];
        const btn = document.createElement("button");
        btn.id = `botrix-${id}-btn`;
        btn.style.cssText = "background: rgba(0,231,1,0.1) !important; color: #00e701 !important; height: 45px; font-weight: bold; border-radius: 4px; border: 1px solid rgba(0,231,1,0.3) !important; cursor: pointer; font-size: 14px; transition: all 0.2s;";
        btn.textContent = cmd.label;

        btn.onclick = () => {
            // Anti-spam inmediato
            if (activeTimers[id] > 0 || btn.disabled) return;

            // Forzar estado deshabilitado inmediatamente localmente
            setButtonState(id, false, cmd.cooldown);

            if (sendChatMessage(cmd.label)) {
                startTimer(id, cmd.cooldown);
                // Pequeño delay opcional para asegurar que el timer se propague,
                // aunque updateTimers ya lo lee de localStorage.
                setTimeout(updateTimers, 50);
            } else {
                // Si falla el envío (ej: canal incorrecto), re-habilitar
                setButtonState(id, true);
            }
        };

        cmdContainer.appendChild(btn);
    });
    updateTimers();
}

function renderCommandEditor() {
    const editorContainer = document.getElementById("botrix-command-editor-list");
    if (!editorContainer) return;

    editorContainer.innerHTML = "";
    Object.keys(BOTRIX_COMMANDS).forEach(id => {
        addCommandRow(id, BOTRIX_COMMANDS[id]);
    });
}

function addCommandRow(id, cmd = { label: "!", cooldown: 900 }) {
    const container = document.getElementById("botrix-command-editor-list");
    if (!container) return;

    const row = document.createElement("div");
    row.className = "botrix-command-row";
    row.dataset.id = id;
    row.draggable = true;

    row.innerHTML = `
        <div class="botrix-drag-handle-cmd" title="Arrastrar para reordenar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="9" cy="12" r="1" fill="currentColor"></circle>
                <circle cx="9" cy="5" r="1" fill="currentColor"></circle>
                <circle cx="9" cy="19" r="1" fill="currentColor"></circle>
                <circle cx="15" cy="12" r="1" fill="currentColor"></circle>
                <circle cx="15" cy="5" r="1" fill="currentColor"></circle>
                <circle cx="15" cy="19" r="1" fill="currentColor"></circle>
            </svg>
        </div>
        <input type="text" class="cmd-label" value="${cmd.label}" style="flex: 2; min-width: 0;" placeholder="!comando">
        <input type="number" class="cmd-cooldown" value="${cmd.cooldown}" style="flex: 1; min-width: 0;" placeholder="Secs">
        <button class="botrix-delete-cmd" title="Eliminar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
    `;

    // DRAG EVENTS (Solo permitir desde el icono de los 6 puntos)
    row.onmousedown = (e) => {
        if (e.target.closest('.botrix-drag-handle-cmd')) {
            row.draggable = true;
        } else {
            row.draggable = false;
        }
    };

    row.ondragstart = (e) => {
        row.classList.add("dragging");
        e.dataTransfer.setData("text/plain", id);
        e.dataTransfer.effectAllowed = "move";
    };

    row.ondragend = () => {
        row.classList.remove("dragging");
        row.draggable = false; // Resetear tras el arrastre
    };

    row.querySelector(".botrix-delete-cmd").onclick = (e) => {
        e.preventDefault();
        row.remove();
    };

    container.appendChild(row);
}

function createPanel() {
    const existing = document.getElementById("botrix-helper-panel");
    if (existing) return;

    const panel = document.createElement("div");
    panel.id = "botrix-helper-panel";
    panel.classList.add("minimized");

    panel.innerHTML = `
  <div id="botrix-drag-handle" style="display: flex; align-items: center; justify-content: space-between; padding: 0 12px; background: #111; border-bottom: 1px solid #222; border-radius: 6px 6px 0 0; cursor: move; height: 48px; box-sizing: border-box;">
    <div style="display: flex; align-items: center; gap: 10px; pointer-events: none;">
        <span style="font-weight: 800; font-size: 13px; letter-spacing: 0.5px; color: #fff;">BotRix Helper</span>
        <div id="botrix-notif-bell" style="width: 10px; height: 10px; background: #ff4444; border-radius: 50%; box-shadow: 0 0 10px #ff4444; display: none; cursor: pointer; animation: pulse 2s infinite; pointer-events: auto;"></div>
    </div>
    <div style="display: flex; align-items: center; gap: 8px; box-sizing: border-box;">
        <div id="botrix-points-display" style="background: rgba(0,231,1,0.08); color: #00e701; padding: 0 8px; border-radius: 4px; border: 1px solid rgba(0,231,1,0.15); font-size: 11px; font-weight: 700; height: 30px !important; display: flex; align-items: center; justify-content: center; box-sizing: border-box !important; margin: 0 !important; pointer-events: none;">Puntos: 0</div>
        <button id="botrix-reload-points" style="background: rgba(0,231,1,0.08); color: #00e701; border: 1px solid rgba(0,231,1,0.15); border-radius: 4px; width: 30px; height: 30px !important; cursor: pointer; display: flex; align-items: center; justify-content: center; padding: 0; transition: background 0.2s; box-sizing: border-box !important; margin: 0 !important;" title="Refrescar Saldo">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="display: block; pointer-events: none;">
            <path d="M23 4v6h-6"></path>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
        <div id="botrix-minimize-btn" class="botrix-minimize-btn" style="height: 30px !important; width: 30px; display: flex; align-items: center; justify-content: center; margin: 0 !important; box-sizing: border-box !important; background: rgba(255, 255, 255, 0.05); border-radius: 4px; font-size: 16px; cursor: pointer;">+</div>
    </div>
  </div>

  <div class="botrix-tabs">
    <button class="botrix-tab-btn active" data-tab="settings" style="flex: 1;">Configuración</button>
    <button class="botrix-tab-btn" data-tab="comandos" style="flex: 1;">Comandos</button>
  </div>

  <div id="tab-settings" class="botrix-tab-content active">
    <div class="botrix-row">
      <label>Tu usuario de Kick</label>
      <input id="botrix-username-input" type="text" placeholder="user123" />
    </div>
    <div class="botrix-row">
      <label>Canal para Alertas</label>
      <input id="botrix-target-channel" type="text" placeholder="Canal actual" />
    </div>
    <div class="botrix-row" style="background: rgba(255,255,255,0.03); padding: 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 5px !important;">
        <label style="margin-bottom: 12px; font-weight: bold; color: #fff;">Alertas</label>
        <div class="botrix-switch-container">
            <span>Notificaciones</span>
            <label class="botrix-switch"><input type="checkbox" id="check-notif-events" checked><span class="botrix-slider"></span></label>
        </div>
        <div class="botrix-switch-container">
            <span>Solo en directo</span>
            <label class="botrix-switch"><input type="checkbox" id="check-notif-live-only"><span class="botrix-slider"></span></label>
        </div>
        <div class="botrix-switch-container">
            <span>Silencio</span>
            <label class="botrix-switch"><input type="checkbox" id="check-notif-mute"><span class="botrix-slider"></span></label>
        </div>
        <div class="botrix-row" style="margin-top: 10px; margin-bottom: 0 !important;">
            <select id="botrix-sound-type" style="width: 100%; background: #111; color: #fff; border: 1px solid #333; padding: 6px; border-radius: 4px;">
                <option value="standard">Standard</option><option value="techno">Digital</option><option value="deep">Eco</option><option value="double">Doble</option>
            </select>
        </div>
    </div>

    <!-- Gestión de Comandos en Ajustes -->
    <div id="botrix-commands-card" class="botrix-row" style="padding: 16px; border-radius: 4px; margin-bottom: 8px !important; transition: all 0.2s;">
        <div id="botrix-commands-collapse-btn" class="botrix-collapsible-header" style="display: flex; align-items: center; justify-content: space-between;">
            <label style="margin-bottom: 0; font-weight: bold; color: #fff; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                Comandos
            </label>
            <div class="botrix-collapse-icon" style="display: flex; align-items: center; justify-content: center; width: 20px; height: 20px; transition: transform 0.4s;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </div>
        </div>
        
        <div id="botrix-commands-collapse-content" class="botrix-collapsible-content">
            <div id="botrix-command-editor-list" style="margin-bottom: 12px;">
                <!-- Filas de comandos dinámicas -->
            </div>
            <button id="botrix-add-command-btn" style="width: 100%; height: 32px; display: flex; align-items: center; justify-content: center; gap: 6px;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                Añadir Comando
            </button>
        </div>
    </div>

    <!-- Configuración Avanzada -->
    <div id="botrix-advanced-card" class="botrix-row" style="padding: 16px; border-radius: 4px; margin-bottom: 8px !important; transition: all 0.2s;">
        <div id="botrix-advanced-collapse-btn" class="botrix-collapsible-header" style="display: flex; align-items: center; justify-content: space-between;">
            <label style="margin-bottom: 0; font-weight: bold; color: #fff; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                Avanzado
            </label>
            <div class="botrix-collapse-icon" style="display: flex; align-items: center; justify-content: center; width: 20px; height: 20px; transition: transform 0.4s;">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </div>
        </div>
        
        <div id="botrix-advanced-collapse-content" class="botrix-collapsible-content">
            <div style="margin-top: 12px; margin-bottom: 12px;">
                <label>Palabras clave puntos</label>
                <input id="botrix-points-keywords" type="text" placeholder="tienes, has, total" />
            </div>
            <button id="botrix-import-template-btn" class="botrix-template-btn" style="width: 100%; background: rgba(0, 231, 1, 0.05); color: #00e701; border: 1px solid rgba(0, 231, 1, 0.2) !important; height: 32px; font-size: 12px; font-weight: bold; cursor: pointer; border-radius: 4px; transition: all 0.2s; margin: 0; padding: 0;">Importar Plantilla</button>
            <input type="file" id="botrix-import-file" accept=".json" style="display: none;">
        </div>
    </div>

    <button id="save-username-btn" style="background: rgba(0,231,1,0.1) !important; color: #00e701 !important; height: 40px; font-weight: bold; border-radius: 4px; border: 1px solid rgba(0,231,1,0.3) !important; cursor: pointer; transition: all 0.2s; margin-top: 8px;">Guardar Cambios</button>
  </div>

  <!-- Pestaña de Comandos -->
  <div id="tab-comandos" class="botrix-tab-content">
    <div id="botrix-commands-container" class="botrix-row" style="display: flex; flex-direction: column; gap: 10px; padding-top: 5px;">
      <!-- Los botones se generan dinámicamente aquí -->
    </div>
  </div>

  <!-- Footer -->
  <div class="botrix-footer" style="background: #181818; border-top: 1px solid rgba(255,255,255,0.07); padding: 8px 12px; display: flex; align-items: center; justify-content: flex-start; border-radius: 0 0 6px 6px; height: 28px; box-sizing: border-box;">
    <div class="botrix-version-tag" style="font-size: 9px; opacity: 0.4; color: #fff; letter-spacing: 1px; text-transform: uppercase; font-family: monospace; pointer-events: none; line-height: 1 !important;">v1.0</div>
  </div>
`;

    document.body.appendChild(panel);

    // LÓGICA UI
    document.getElementById("botrix-drag-handle").onclick = (e) => {
        if (panel.classList.contains("minimized")) {
            panel.classList.remove("minimized");
            document.getElementById("botrix-minimize-btn").textContent = "−";
        }
    };

    document.getElementById("botrix-minimize-btn").onclick = (e) => {
        e.stopPropagation();
        panel.classList.toggle("minimized");
        document.getElementById("botrix-minimize-btn").textContent = panel.classList.contains("minimized") ? "+" : "−";
    };

    document.getElementById("botrix-notif-bell").onclick = () => {
        hideNotificationBell(true);
    };

    const tabs = panel.querySelectorAll(".botrix-tab-btn");
    tabs.forEach(t => t.onclick = () => {
        tabs.forEach(x => x.classList.remove("active"));
        t.classList.add("active");
        panel.querySelectorAll(".botrix-tab-content").forEach(c => c.classList.remove("active"));
        document.getElementById(`tab-${t.dataset.tab}`).classList.add("active");
    });

    document.getElementById("save-username-btn").onclick = () => {
        localStorage.setItem(STORAGE_KEY_USERNAME, document.getElementById("botrix-username-input").value.trim());
        localStorage.setItem(STORAGE_KEY_TARGET, document.getElementById("botrix-target-channel").value.trim().toLowerCase());
        localStorage.setItem(STORAGE_KEY_NOTIF, document.getElementById("check-notif-events").checked);
        localStorage.setItem(STORAGE_KEY_MUTE, document.getElementById("check-notif-mute").checked);
        localStorage.setItem(STORAGE_KEY_SOUND, document.getElementById("botrix-sound-type").value);
        localStorage.setItem(STORAGE_KEY_LIVE_ONLY, document.getElementById("check-notif-live-only").checked);
        localStorage.setItem(STORAGE_KEY_POINTS_KEYWORDS, document.getElementById("botrix-points-keywords").value.trim() || "tienes, has, ahora tienes, total");

        const newCmds = {};
        const rows = document.querySelectorAll(".botrix-command-row");
        rows.forEach((row, index) => {
            const label = row.querySelector(".cmd-label").value.trim();
            const cooldown = parseInt(row.querySelector(".cmd-cooldown").value) || 0;
            if (label) {
                const id = row.dataset.id || `custom_${Date.now()}_${index}`;
                newCmds[id] = { label, cooldown };
            }
        });

        localStorage.setItem(STORAGE_KEY_COMMANDS, JSON.stringify(newCmds));

        loadAllSettings();
    };

    const importInput = document.getElementById("botrix-import-file");
    document.getElementById("botrix-import-template-btn").onclick = (e) => {
        e.stopPropagation();
        importInput.click();
    };

    importInput.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const data = JSON.parse(ev.target.result);

                if (data.streamerName !== undefined) localStorage.setItem(STORAGE_KEY_TARGET, data.streamerName);
                if (data.usuarioKick !== undefined) localStorage.setItem(STORAGE_KEY_USERNAME, data.usuarioKick);
                if (data.targetChannel !== undefined) localStorage.setItem(STORAGE_KEY_TARGET, data.targetChannel);

                if (data.leerPuntos !== undefined) {
                    let pKeys = "";
                    if (Array.isArray(data.leerPuntos)) pKeys = data.leerPuntos.join(', ');
                    else if (typeof data.leerPuntos === 'object') pKeys = Object.values(data.leerPuntos).join(', ');
                    else pKeys = String(data.leerPuntos);
                    localStorage.setItem(STORAGE_KEY_POINTS_KEYWORDS, pKeys);
                } else if (data.pointsKeywords !== undefined) {
                    localStorage.setItem(STORAGE_KEY_POINTS_KEYWORDS, data.pointsKeywords);
                }

                if (data.commands !== undefined) localStorage.setItem(STORAGE_KEY_COMMANDS, JSON.stringify(data.commands));
                if (data.soundType !== undefined) localStorage.setItem(STORAGE_KEY_SOUND, data.soundType);
                if (data.notifEnabled !== undefined) localStorage.setItem(STORAGE_KEY_NOTIF, data.notifEnabled);
                if (data.muteEnabled !== undefined) localStorage.setItem(STORAGE_KEY_MUTE, data.muteEnabled);
                if (data.liveOnly !== undefined) localStorage.setItem(STORAGE_KEY_LIVE_ONLY, data.liveOnly);

                loadAllSettings();
                importInput.value = "";

                const importBtn = document.getElementById("botrix-import-template-btn");
                if (importBtn) {
                    const originalCss = importBtn.style.cssText;
                    importBtn.textContent = "¡Cargado!";
                    importBtn.style.cssText = "width: 100%; background: #00e701 !important; color: #000 !important; cursor: pointer; border-radius: 4px; transition: all 0.2s; height: 32px; font-size: 12px; font-weight: bold; border: none !important; margin: 0; padding: 0;";
                    setTimeout(() => {
                        importBtn.textContent = "Importar Plantilla";
                        importBtn.style.cssText = originalCss;
                    }, 2000);
                }
            } catch (err) {
                console.error("Error validando JSON:", err);
                alert("Error: Archivo de plantilla corrupto o inválido.");
            }
        };
        reader.readAsText(file);
    };

    document.getElementById("botrix-add-command-btn").onclick = (e) => {
        e.stopPropagation();
        addCommandRow(`custom_${Date.now()}`);
    };

    // LÓGICA COLAPSABLE
    const collBtn = document.getElementById("botrix-commands-collapse-btn");
    const collContent = document.getElementById("botrix-commands-collapse-content");
    collBtn.onclick = () => {
        const isExp = collContent.classList.toggle("expanded");
        collBtn.classList.toggle("expanded");
        const icon = collBtn.querySelector('.botrix-collapse-icon');
        if (icon) {
            icon.style.transform = isExp ? 'rotate(180deg)' : 'rotate(0deg)';
        }
    };

    // LÓGICA DRAG & DROP PARA LA LISTA
    const listContainer = document.getElementById("botrix-command-editor-list");
    listContainer.ondragover = (e) => {
        e.preventDefault();
        const dragging = document.querySelector(".dragging");
        if (!dragging) return;
        const afterElement = getDragAfterElement(listContainer, e.clientY);
        if (afterElement == null) {
            listContainer.appendChild(dragging);
        } else {
            listContainer.insertBefore(dragging, afterElement);
        }
    };

    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.botrix-command-row:not(.dragging)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) {
                return { offset: offset, element: child };
            } else {
                return closest;
            }
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }

    const advBtn = document.getElementById("botrix-advanced-collapse-btn");
    const advContent = document.getElementById("botrix-advanced-collapse-content");
    advBtn.onclick = () => {
        const isExp = advContent.classList.toggle("expanded");
        advBtn.classList.toggle("expanded");
        const icon = advBtn.querySelector('.botrix-collapse-icon');
        if (icon) {
            icon.style.transform = isExp ? 'rotate(180deg)' : 'rotate(0deg)';
        }
    };

    const bReload = document.getElementById("botrix-reload-points");
    if (bReload) bReload.onclick = (e) => {
        e.stopPropagation();
        sendChatMessage("!points");
    };

    document.getElementById("botrix-sound-type").onchange = () => {
        localStorage.setItem(STORAGE_KEY_SOUND, document.getElementById("botrix-sound-type").value);
        playNotificationSound(true); // Forzar reproducción sin esperas
    };

    document.getElementById("check-notif-events").onchange = () => {
        document.getElementById("check-notif-mute").disabled = !document.getElementById("check-notif-events").checked;
    };

    loadAllSettings();
    loadPoints();
}

function sendChatMessage(text) {
    const chan = getCurrentChannel();
    // REGLA DE ESCRITURA: Solo escribir en el canal objetivo si está definido
    if (targetChannel && chan !== targetChannel) {
        return false;
    }

    const selectors = [
        '.editor-input',
        '#chat-input .tiptap',
        '.chat-message-input .ProseMirror',
        'div.chat-message-input div[contenteditable="true"]',
        '[data-placeholder*="mensaje" i]',
        '[data-placeholder*="message" i]'
    ];

    let chatInput = null;
    for (const s of selectors) {
        chatInput = document.querySelector(s);
        if (chatInput) {
            console.log("[BotRix DEBUG] Chat encontrado vía selector:", s);
            break;
        }
    }

    if (!chatInput) {
        const editables = document.querySelectorAll('[contenteditable="true"]');
        if (editables.length === 1) {
            chatInput = editables[0];
            console.log("[BotRix DEBUG] Chat encontrado vía único editable.");
        }
    }

    if (!chatInput) {
        console.error("[BotRix DEBUG] NO SE ENCONTRÓ EL CHAT.");
        return;
    }

    chatInput.focus();
    try {
        document.execCommand('insertText', false, text);
    } catch (e) {
        chatInput.innerHTML = text;
    }

    setTimeout(() => {
        const enter = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true };
        chatInput.dispatchEvent(new KeyboardEvent('keydown', enter));

        const sendBtn = document.querySelector('button.chat-send-btn') ||
            document.querySelector('.chat-input-actions button');

        if (sendBtn) {
            console.log("[BotRix DEBUG] Clic en botón de enviar físico.");
            sendBtn.click();
        }
    }, 200);
    return true;
}

function playNotificationSound(force = false) {
    if (isMuted && !force) return;

    if (!force) {
        const now = Date.now();
        const lastSound = parseInt(localStorage.getItem("botrix_helper_last_sound_time") || "0");
        if (now - lastSound < 5000) return;
        localStorage.setItem("botrix_helper_last_sound_time", now.toString());
    }

    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const type = localStorage.getItem(STORAGE_KEY_SOUND) || "standard";
        const playTone = (freq, dur, oscType = "sine", vol = 0.1) => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain); gain.connect(audioCtx.destination);
            osc.type = oscType;
            osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
            gain.gain.setValueAtTime(vol, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + dur);
            osc.start(); osc.stop(audioCtx.currentTime + dur);
        };
        if (type === "standard") playTone(880, 0.4);
        else if (type === "techno") playTone(1600, 0.15, "square", 0.05);
        else if (type === "deep") playTone(150, 0.8, "sine", 0.2);
        else if (type === "double") { playTone(550, 0.15); setTimeout(() => playTone(660, 0.15), 150); }
    } catch (e) { }
}

async function triggerNotification(fromBroadcast = false, signature = "") {
    if (!isNotificationsEnabled) return;

    // FILTRO DE ESTADO EN DIRECTO
    const checkChan = targetChannel || getCurrentChannel();
    if (isLiveOnlyEnabled && checkChan) {
        const isLive = await checkLiveStatusAPI(checkChan);
        if (!isLive) {
            console.log(`[BotRix] Notificación omitida: ${checkChan} no está en directo.`);
            return;
        }
    }

    const now = Date.now();
    const isTimerAlarm = signature.startsWith("ALARM_");

    // PERSISTENCIA MULTI-PESTAÑA
    const lastStoredSignature = localStorage.getItem("botrix_helper_last_alert_signature");
    const lastStoredTime = parseInt(localStorage.getItem("botrix_helper_last_alert_time") || "0");

    const debounceTime = 2000;
    if (signature === lastStoredSignature && (now - lastStoredTime) < debounceTime) return;

    localStorage.setItem("botrix_helper_last_alert_signature", signature);
    localStorage.setItem("botrix_helper_last_alert_time", now.toString());
    localStorage.setItem(STORAGE_KEY_BELL_VISIBLE, "true");

    const bell = document.getElementById("botrix-notif-bell");
    if (bell) bell.style.display = "block";

    // REGLA DE SONIDO MEJORADA:
    const shouldPlaySound = isTimerAlarm ? true : (fromBroadcast ? document.hasFocus() : true);

    if (shouldPlaySound) {
        playNotificationSound();
    }

    if (!fromBroadcast) {
        bc.postMessage({ type: 'TRIGGER_NOTIF', signature: signature });
    }
}

function getCurrentChannel() {
    const p = window.location.pathname.split('/').filter(x => x !== "");
    if (p.length === 0) return "";

    const blacklist = ["video", "videos", "clips", "categories", "search", "settings", "following", "browse"];
    if (blacklist.includes(p[0])) return "";

    return p[0].toLowerCase();
}

function isStreamerLive(channelName) {
    const target = channelName || getCurrentChannel();
    if (!target) return false;

    const now = Date.now();
    if (now - liveCache.lastCheck < 5000) {
        return liveCache.isLive;
    }

    if (target === getCurrentChannel()) {
        const isLive = checkLiveStatusSync();
        liveCache = { isLive, lastCheck: now };
        return isLive;
    }

    updateLiveCache();
    return liveCache.isLive;
}

function checkLiveStatusSync() {
    const videos = document.getElementsByTagName('video');
    for (let v of videos) {
        if (v.readyState >= 1 && !v.paused && v.closest('.video-player')) return true;
        if (v.readyState >= 1 && v.src && !v.src.includes('blob'))
            if (v.readyState >= 2) return true;
    }
    const ogType = document.querySelector('meta[property="og:type"]');
    if (ogType && ogType.content.includes('video')) {
        const twitterViewers = document.querySelector('meta[name="twitter:label1"]');
        if (twitterViewers && (twitterViewers.content.includes('Viewers') || twitterViewers.content.includes('Espectadores'))) return true;
    }

    const liveBadge = document.querySelector('.bg-red-600.uppercase, [class*="live-status-badge"], .v-badge.red, .live-badge');
    if (liveBadge) {
        const txt = liveBadge.textContent.toUpperCase();
        if (txt.includes("LIVE") || txt.includes("DIRECTO") || txt.includes("EN VIVO")) return true;
    }

    const viewers = document.querySelector('[class*="viewers-count"], [class*="view-count"], .v-viewer-count');
    if (viewers && viewers.textContent.trim() !== "") return true;

    const scripts = document.getElementsByTagName('script');
    for (let i = 0; i < scripts.length; i++) {
        const c = scripts[i].textContent;
        if (c.includes('__NUXT__') && c.includes('"livestream":{') && !c.includes('"livestream":null')) return true;
    }

    return false;
}

async function checkLiveStatusAPI(channelName) {
    if (!channelName) return false;
    try {
        const response = await fetch(`/api/v1/channels/${channelName}`);
        if (response.ok) {
            const data = await response.json();
            const isLive = data.livestream !== null;

            liveCache = { isLive, lastCheck: Date.now() };
            return isLive;
        }
    } catch (err) {
        console.warn("[BotRix] Error en fetch API, usando fallback de escaneo...");
    }

    const scripts = document.getElementsByTagName('script');
    for (let i = 0; i < scripts.length; i++) {
        const c = scripts[i].textContent;
        if (c.includes('__NUXT__')) {
            if (c.includes('"livestream":null') || c.includes('livestream:null')) {
                liveCache = { isLive: false, lastCheck: Date.now() };
                return false;
            }
            if (c.includes('"livestream":{') || c.includes('livestream:{')) {
                liveCache = { isLive: true, lastCheck: Date.now() };
                return true;
            }
        }
    }

    return checkLiveStatusSync();
}

function updateLiveCache() {
    const isLive = checkLiveStatusSync();
    liveCache = { isLive, lastCheck: Date.now() };
}

function processBotrixMessage(username, text) {
    if (isInitializing || !text) return;
    const norm = text.toLowerCase();
    const user = currentUsername.toLowerCase();

    if (user && (norm.includes(user) || norm.includes("hola"))) {
        updatePointsFromText(text);
    }
}

function makePanelDraggable() {
    const p = document.getElementById("botrix-helper-panel");
    const h = document.getElementById("botrix-drag-handle");
    let isD = false, sx, sy, il, it;
    h.onmousedown = (e) => {
        if (p.classList.contains("minimized")) return;
        isD = true; p.style.transition = "none";
        sx = e.clientX; sy = e.clientY;
        const r = p.getBoundingClientRect();
        il = r.left; it = r.top;
        p.style.left = il + "px"; p.style.top = it + "px";
        p.style.right = "auto"; p.style.bottom = "auto";
        document.onmousemove = (me) => {
            if (!isD) return;
            p.style.left = (il + (me.clientX - sx)) + "px";
            p.style.top = (it + (me.clientY - sy)) + "px";
        };
        document.onmouseup = () => {
            isD = false; p.style.transition = "all 0.3s";
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };
}

let processedNodes = new WeakSet();
let recentMatches = new Set();
let checkTimer = null;

function observeChat() {
    const observer = new MutationObserver((mutations) => {
        if (isInitializing) return;

        const chan = getCurrentChannel();
        if (targetChannel && chan !== targetChannel) return;

        for (let i = 0; i < mutations.length; i++) {
            const addedNodes = mutations[i].addedNodes;
            for (let j = 0; j < addedNodes.length; j++) {
                const node = addedNodes[j];
                if (node.nodeType !== 1 || processedNodes.has(node)) continue;
                processedNodes.add(node);

                if (node.id === "botrix-helper-panel" || node.closest(".nav-bar") || node.closest(".auth-modal")) continue;

                const txt = (node.textContent || "").trim().replace(/[\u200B-\u200D\uFEFF]/g, '');
                if (txt && txt.length > 0 && txt.length < 500) {
                    const lowerTxt = txt.toLowerCase();
                    const lowerUser = currentUsername ? currentUsername.toLowerCase() : "";

                    // DETECCIÓN DE COMANDOS PROPIOS
                    let matchedCmd = null;
                    Object.keys(BOTRIX_COMMANDS).forEach(id => {
                        const label = BOTRIX_COMMANDS[id].label.toLowerCase();
                        if (lowerTxt.includes(label) && lowerUser && lowerTxt.includes(lowerUser)) {
                            matchedCmd = id;
                        }
                    });

                    if (matchedCmd) {
                        bc.postMessage({ type: 'CHECK_RESET' });
                        startTimer(matchedCmd, BOTRIX_COMMANDS[matchedCmd].cooldown);
                        continue;
                    }

                    let isFromBotrix = false;
                    const attr = node.getAttribute("data-chat-entry-user");
                    const userElement = node.querySelector('.chat-entry-username, .chat-message-identity, [data-chat-entry-user], span.font-bold');

                    if (attr && attr.toLowerCase().includes("botrix")) {
                        isFromBotrix = true;
                    } else if (userElement && userElement.textContent.toLowerCase().includes("botrix")) {
                        isFromBotrix = true;
                    } else {
                        isFromBotrix = /botrix/i.test(lowerTxt.substring(0, 35));
                    }

                    if (isFromBotrix) {
                        if (node.getAttribute("contenteditable") === "true" || node.closest('[contenteditable="true"]')) continue;

                        const signature = txt.replace(/\s+/g, "");
                        if (recentMatches.has(signature)) continue;
                        recentMatches.add(signature);
                        setTimeout(() => recentMatches.delete(signature), 1500);

                        processBotrixMessage("BotRix", txt);
                    }
                }
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

function updatePointsDisplay(p) {
    const d = document.getElementById("botrix-points-display");
    if (d) d.textContent = `Puntos: ${p.toLocaleString()}`;
}

function loadPoints() {
    const s = localStorage.getItem(STORAGE_KEY_POINTS);
    if (s) {
        currentPoints = parseInt(s) || 0;
        updatePointsDisplay(currentPoints);
    }
}

function updatePointsFromText(t) {
    if (!currentUsername) return;

    const plainTxt = t.replace(/[\u200B-\u200D\uFEFF]/g, '');
    const lowerTxt = plainTxt.toLowerCase();

    const safeMention = `@${currentUsername.toLowerCase()}`;
    if (!lowerTxt.includes(safeMention)) {
        return;
    }

    const kwArray = currentPointsKeywords.split(',').map(k => k.trim()).filter(k => k.length > 0);
    if (kwArray.length === 0) return;

    let matchFound = false;
    let extractedPoints = null;

    for (let phrase of kwArray) {
        let regex;
        if (phrase.includes("[points]")) {
            let p = phrase.replace(/@\[user\]/gi, '\x01USER_MENTION\x02')
                .replace(/\[user\]/gi, '\x01USER\x02')
                .replace(/\[points\]/gi, '\x01POINTS\x02');

            p = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const safeUser = currentUsername.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

            p = p.replace(/\x01USER_MENTION\x02/g, `@${safeUser}`);
            p = p.replace(/\x01USER\x02/g, `@${safeUser}`);
            p = p.replace(/\x01POINTS\x02/g, '(\\d+[,.]?\\d*)');

            p = p.replace(/ /g, '[\\s\\xA0]+');

            regex = new RegExp(p, 'i');
        } else {
            const escapedKw = phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            regex = new RegExp(`(?:${escapedKw})[\\s\\xA0]*:?[\\s\\xA0]*(\\d+[,.]?\\d*)`, 'i');
        }

        const m = plainTxt.match(regex);
        if (m && m[1]) {
            extractedPoints = m[1];
            matchFound = true;
            break;
        }
    }

    if (matchFound && extractedPoints) {
        const valueStr = extractedPoints.replace(/[,.]/g, '');
        currentPoints = parseInt(valueStr) || 0;
        localStorage.setItem(STORAGE_KEY_POINTS, currentPoints);
        updatePointsDisplay(currentPoints);
    }
}

function appendMessageToPanel(t, tm) {
    const c = document.getElementById("botrix-messages");
    if (!c) return;
    const i = document.createElement("div");
    i.className = "botrix-message-item";
    i.innerHTML = `<span style="opacity:0.5;font-size:9px;">${tm}</span><br>${t}`;
    c.prepend(i);

    while (c.children.length > 20) {
        c.removeChild(c.lastChild);
    }
}

function init() {
    createPanel();
    makePanelDraggable();
    initGlobalLoop();
    observeTheaterMode();

    setInterval(updateLiveCache, 120000);
    updateLiveCache();

    setTimeout(() => {
        console.log("[BotRix] Pasado periodo de seguridad (3s).");
        isInitializing = false;
        observeChat();
    }, 3000);
}

function observeTheaterMode() {
    const panel = document.getElementById("botrix-helper-panel");
    if (!panel) return;

    const check = () => {
        try {
            const body = document.body;
            let isTheater =
                body.getAttribute("data-theatre") === "true" ||
                body.getAttribute("data-theatre-mode") === "true" ||
                body.classList.contains("theatre-mode") ||
                body.classList.contains("theater-mode");

            const theaterBtn = document.querySelector('button[aria-label*="Theater"], button[aria-label*="teatro"]');
            if (!isTheater && theaterBtn) {
                isTheater = theaterBtn.getAttribute('aria-pressed') === 'true';
            }

            const nav = document.querySelector('nav, aside, .sidebar-container, #side-nav');
            if (!isTheater && nav) {
                const rect = nav.getBoundingClientRect();
                if (rect.width < 10 || rect.left < -50) {
                    isTheater = true;
                }
            }

            if (isTheater) {
                if (!panel.classList.contains("theater-active")) {
                    panel.classList.add("theater-active");
                }
            } else {
                if (panel.classList.contains("theater-active")) {
                    panel.classList.remove("theater-active");
                }
            }
        } catch (err) {
        }
    };

    setInterval(check, 500);
    check();
}

init();